{
	"patcher" : 	{
		"rect" : [ 50.0, 40.0, 250.0, 190.0 ],
		"bgcolor" : [ 0.98, 0.98, 0.96, 1.0 ],
		"bglocked" : 0,
		"defrect" : [ 50.0, 40.0, 250.0, 190.0 ],
		"openrect" : [ 0.0, 0.0, 0.0, 0.0 ],
		"openinpresentation" : 0,
		"default_fontsize" : 10.0,
		"default_fontface" : 0,
		"default_fontname" : "Arial",
		"gridonopen" : 0,
		"gridsize" : [ 15.0, 15.0 ],
		"gridsnaponopen" : 0,
		"toolbarvisible" : 1,
		"boxanimatetime" : 200,
		"imprint" : 0,
		"metadata" : [  ],
		"boxes" : [ 			{
				"box" : 				{
					"maxclass" : "newobj",
					"text" : "prepend set",
					"id" : "obj-1",
					"fontsize" : 7.9,
					"numinlets" : 1,
					"numoutlets" : 1,
					"patching_rect" : [ 34.0, 109.0, 60.0, 17.0 ],
					"outlettype" : [ "" ],
					"fontname" : "Geneva"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "outlet",
					"id" : "obj-2",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 116.0, 131.0, 15.0, 15.0 ],
					"comment" : "output value"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "newobj",
					"text" : "r #1",
					"id" : "obj-3",
					"fontsize" : 7.9,
					"numinlets" : 0,
					"numoutlets" : 1,
					"patching_rect" : [ 34.0, 87.0, 181.0, 17.0 ],
					"outlettype" : [ "" ],
					"fontname" : "Geneva"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "newobj",
					"text" : "s #1",
					"id" : "obj-4",
					"fontsize" : 7.9,
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 34.0, 63.0, 181.0, 17.0 ],
					"fontname" : "Geneva"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "outlet",
					"id" : "obj-5",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 34.0, 131.0, 15.0, 15.0 ],
					"comment" : "set value"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "inlet",
					"id" : "obj-6",
					"numinlets" : 0,
					"numoutlets" : 1,
					"patching_rect" : [ 34.0, 33.0, 15.0, 15.0 ],
					"outlettype" : [ "" ],
					"comment" : "value"
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "comment",
					"text" : "set value",
					"id" : "obj-7",
					"fontsize" : 7.9,
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 50.0, 131.0, 49.0, 17.0 ],
					"fontname" : "Geneva",
					"frgb" : [ 0.0, 0.0, 0.0, 1.0 ]
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "comment",
					"text" : "value",
					"id" : "obj-8",
					"fontsize" : 7.9,
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 56.0, 33.0, 32.0, 17.0 ],
					"fontname" : "Geneva",
					"frgb" : [ 0.0, 0.0, 0.0, 1.0 ]
				}

			}
, 			{
				"box" : 				{
					"maxclass" : "comment",
					"text" : "output value",
					"id" : "obj-9",
					"fontsize" : 7.9,
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 135.0, 130.0, 63.0, 17.0 ],
					"fontname" : "Geneva",
					"frgb" : [ 0.0, 0.0, 0.0, 1.0 ]
				}

			}
 ],
		"lines" : [ 			{
				"patchline" : 				{
					"source" : [ "obj-3", 0 ],
					"destination" : [ "obj-2", 0 ],
					"hidden" : 0,
					"midpoints" : [ 43.5, 105.0, 125.0, 105.0 ]
				}

			}
, 			{
				"patchline" : 				{
					"source" : [ "obj-1", 0 ],
					"destination" : [ "obj-5", 0 ],
					"hidden" : 0
				}

			}
, 			{
				"patchline" : 				{
					"source" : [ "obj-3", 0 ],
					"destination" : [ "obj-1", 0 ],
					"hidden" : 0
				}

			}
, 			{
				"patchline" : 				{
					"source" : [ "obj-6", 0 ],
					"destination" : [ "obj-4", 0 ],
					"hidden" : 0
				}

			}
 ]
	}

}
