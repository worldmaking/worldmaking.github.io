
this.outlets = 2;

var roomsize = 30;
var pos, quat, unitz;

var headheight = 1.6;

var pos = [0., headheight, 0.];
var quat = [0.,0.,0.,0.];
var unitz = [0., 0., 0.];

var walking = false;
var walkrate = 0.0;
var walkspeed = 1;

var turning = false;
var azimuth = 0.0;
var turnrate = 0.0;
var turnspeed = 15;

var belling = false;

var sounding = false;

var panning = false;
var pancount = 0;

var soundfiles = [
    "blaster.aif", 
    "chains.wav", 
    "cymbal.wav", 
    "drumroll.wav", 
    "flute.wav", 
    "gong.wav", 
    "shake.wav", 
    "synth.wav", 
    "tearing.wav", 
    "triangle.wav", 
    "voice_children.wav", 
    "voice_dark.wav", 
    "voice_down.wav"
];


function reset()
{
    pos = [0., headheight, 0.];
    quat = [0.,0.,0.,0.];
    unitz = [0., 0., 0.];
    azimuth = turnrate = 0.;
    walkrate = 0.;
    walking = false;
    turning = false;
    belling = false;
    sounding = false;
    
    outlet(0, "setsound", 0, "bell.wav", 1., 0.5);
    outlet(0, "move", 0, 0, headheight, 0, 0, 0, 0);
    
    outlet(0, "setsound", 23, "chains.wav", 1., 0.);
    outlet(0, "move", 23, 0, headheight, 0, 0, 0, 0);
    
    for (var i=1;i<23;i++)
    {
        outlet(0, "setsound", i,
            soundfiles[i % soundfiles.length],
            1., 0.
        );
        outlet(0, "move", i,
            (Math.random()-0.5) * roomsize * 2,
            headheight, // Math.random() * 11,
            (Math.random()-0.5) * roomsize * 2, 
            0., 0., 0., 0.
        );            
    }

    outlet(0, "enable", 1);

}

function setquat(w, x, y, z, ux, uy, uz)
{
    quat = [w, x, y, z];
    unitz = [ux, uy, uz];
}

function walk(b) { 
    walking = b; 
    if (b) {} else 
    {
        pos = [0., headheight, 0.];
        quat = [0.,0.,0.,0.];
        unitz = [0., 0., 0.];
        azimuth = turnrate = 0.;
    }
}
function turn(b) { turning = b; }
function sounds(b) { sounding = b; }
function pan(b) { panning = b; }

function bell(b) 
{ 
    if (b)
    {
        outlet(0, "play", 0, 1, 0.5);
    } else {
        outlet(0, "stop", 0);
    }
}

function bang() 
{
    if (walking) 
    {
        if (Math.random() < 0.20) {
            walkrate = Math.random() * walkspeed;
        }
        
        for (var i=0;i<3;i+=2) 
        {
            pos[i] += unitz[i] * roomsize/30;
            
            // bounce at walls:
            if (pos[i] > roomsize || pos[i] < -roomsize) {
                pos[i] = 0;
            }
        }
        walkrate *= 0.9;
        //post(pos, "\n");

		outlet(1, "setquat", azimuth, 0., 0.);
		//post(pos, "\n");
	
		// update the simulation viewpoint
		outlet(0, "view", pos, quat);
    }

    if (turning) {
        if (Math.random() < 0.05) {
            turnrate += (Math.random()-0.5) * turnspeed;
        }
        azimuth += turnrate;
        turnrate *= 0.9;

		outlet(1, "setquat", azimuth, 0., 0.);
		//post(pos, "\n");
	
		// update the simulation viewpoint
		outlet(0, "view", pos, quat);
    }
    
    if (sounding && Math.random() < 0.1) 
    {
        var i = Math.ceil(Math.random() * 22);
        outlet(0, "move", i,
            (Math.random()-0.5) * roomsize * 2,
            headheight, // Math.random() * 11,
            (Math.random()-0.5) * roomsize * 2, 
            0., 0., 0., 0.
        );    
        outlet(0, "play", i, 0, 0.5);
    }
    
    if (panning)
    {
        outlet(0, "view", 0, headheight, 0, 0, 0, 0, 0);

        pancount = (pancount + 3) % 360;

        var dist = 5; // * Math.sin(pancount * 0.01);

        outlet(0, "move", 3, 
                dist * Math.cos(pancount * 0.01745329252), 
                headheight, 
                dist * Math.sin(pancount * 0.01745329252), 
                0, 0, 0, 0);
        
        if (pancount % 10 == 0)
        {
            
            outlet(0, "play", 3, 0);
        }
    }
    


}